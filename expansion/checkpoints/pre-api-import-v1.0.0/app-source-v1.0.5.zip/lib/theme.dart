import 'package:flutter/material.dart';

/// 「红妆」全局配色与主题。取自原型 index.html 的 CSS 变量。
class HzColors {
  HzColors._();

  static const Color bg = Color(0xFFFBF8F3); // 奶白底
  static const Color card = Color(0xFFFFFFFF); // 卡片
  static const Color ink = Color(0xFF2B2B2B); // 正文深墨灰
  static const Color ink2 = Color(0xFF8C857C); // 辅助浅墨灰
  static const Color ink3 = Color(0xFFB8B0A4); // 更浅墨灰
  static const Color line = Color(0xFFEDE6DA); // 分割线
  static const Color chip = Color(0xFFF3EEE4); // 浅奶白芯片
  static const Color seal = Color(0xFF7A7263); // 印章线
  static const Color sealBorder = Color(0xFF9A8F7E); // 印章描边
  static const Color markBg = Color(0xFFEDE5D6); // 长按高亮
  static const Color btnBorder = Color(0xFF57524A); // 按钮描边
}

/// 去掉 Android 默认的淡蓝色弧形回弹/发光限位特效（overscroll glow）。
class NoGlowScrollBehavior extends MaterialScrollBehavior {
  const NoGlowScrollBehavior();

  @override
  Widget buildOverscrollIndicator(
    BuildContext context,
    Widget child,
    ScrollableDetails details,
  ) {
    return child;
  }
}

ThemeData buildTheme() {
  final base = ThemeData(
    useMaterial3: false,
    brightness: Brightness.light,
    scaffoldBackgroundColor: HzColors.bg,
    fontFamilyFallback: const [
      'PingFang SC',
      'Microsoft YaHei',
      'sans-serif',
    ],
    colorScheme: const ColorScheme.light(
      primary: HzColors.ink,
      onPrimary: Color(0xFFF7F2E9),
      surface: HzColors.bg,
      onSurface: HzColors.ink,
    ),
  );
  return base.copyWith(
    splashFactory: NoSplash.splashFactory,
    highlightColor: Colors.transparent,
    textTheme: base.textTheme.apply(
      bodyColor: HzColors.ink,
      displayColor: HzColors.ink,
    ),
  );
}
