import 'dart:io';
import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';

import 'package:hongzhuang_app/models.dart';

void main() {
  test('981篇精选原文；译注完整条目有标签、注释及字典覆盖', () {
    final poemsJson =
        File('assets/data/poems.json').readAsStringSync();
    final dictJson = File('assets/data/dict.json').readAsStringSync();
    final repo = Repo.fromJson(poemsJson, dictJson);
    final raw = jsonDecode(poemsJson) as Map<String, dynamic>;
    final rawById = {for (final p in raw['items'] as List) p['id']: p};

    expect(repo.items.length, 981);
    // 内容持续补全，不能把历史字词数量写死成上限。
    expect(repo.chars.length, greaterThanOrEqualTo(2698));
    expect(repo.words.length, greaterThanOrEqualTo(1342));

    // D阶段待补原文留空译注，完整篇目保留有效译注。
    for (final p in repo.items) {
      expect(p.content, isNotEmpty, reason: p.id);
      if (p.translation.isEmpty) {
        expect(p.notes, isEmpty, reason: p.id);
      } else if (rawById[p.id]['editorialStatus'] != 'original_only') {
        expect(p.notes.length, greaterThanOrEqualTo(3), reason: p.id);
        expect(p.notes.length, lessThanOrEqualTo(18), reason: p.id);
        expect(p.tags, isNotEmpty, reason: p.id);
        for (final code in p.content.runes) {
          if ((code >= 0x4e00 && code <= 0x9fff) || code == 0x3007) {
            final char = String.fromCharCode(code);
            final entry = repo.chars[char];
            expect(entry, isNotNull, reason: '${p.id}: $char');
            expect(entry!.pinyin, isNotEmpty, reason: '${p.id}: $char');
            expect([...entry.meanings, ...entry.ancient], isNotEmpty,
                reason: '${p.id}: $char');
          }
        }
      }
    }

    const counts = {'唐诗': 300, '宋词': 300, '元曲': 281, '古文': 100};
    for (final cat in counts.keys) {
      expect(repo.items.where((p) => p.category == cat).length, counts[cat]);
    }
    for (final poem in repo.items.where((p) => p.category == '元曲')) {
      final chars = poem.content.runes.where((c) =>
          (c >= 0x3400 && c <= 0x9fff) || c == 0x3007).length;
      expect(chars, lessThan(100), reason: poem.id);
    }
  });

  test('部分译文可读取，原有译文优先，原文变更拒绝旧补充记录', () {
    final row = {'id':'tang-001','content':'原文','author':'作者','translation':''};
    final extra = {'baseContent':'原文','baseAuthor':'作者','translation':'已采集的译文','notes':[],'tags':[]};
    const dictionaryJson = '{"chars":{},"words":{}}';
    String encode() => jsonEncode({'items':[row],'translationImports':{'tang-001':extra}});
    expect(Repo.fromJson(encode(), dictionaryJson).items.single.translation, '已采集的译文');
    row['translation'] = '原有译文';
    expect(Repo.fromJson(encode(), dictionaryJson).items.single.translation, '原有译文');
    row['translation'] = '';
    extra['baseContent'] = '其他原文';
    expect(Repo.fromJson(encode(), dictionaryJson).items.single.translation, isEmpty);
  });
}
